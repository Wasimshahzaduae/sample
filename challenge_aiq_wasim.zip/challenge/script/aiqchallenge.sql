-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.28-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for aiqchallenge
CREATE DATABASE IF NOT EXISTS `aiqchallenge` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `aiqchallenge`;

-- Dumping structure for table aiqchallenge.fictionalstorelocation
CREATE TABLE IF NOT EXISTS `fictionalstorelocation` (
  `store_location_id` int(11) DEFAULT NULL,
  `store_location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptavgorderqtybyproduct
CREATE TABLE IF NOT EXISTS `rptavgorderqtybyproduct` (
  `product_id` int(11) DEFAULT NULL,
  `avg_quantity` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptconsolidatedsalesdata
CREATE TABLE IF NOT EXISTS `rptconsolidatedsalesdata` (
  `order_id` bigint(20) DEFAULT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `quantity` bigint(20) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `id` bigint(20) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `username` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `lat` text DEFAULT NULL,
  `lng` text DEFAULT NULL,
  `store_location` text DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `sales_amount` double DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `month` text DEFAULT NULL,
  `quarter` text DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbycustomer
CREATE TABLE IF NOT EXISTS `rptsalesbycustomer` (
  `customer_id` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbymonth
CREATE TABLE IF NOT EXISTS `rptsalesbymonth` (
  `month` varchar(30) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbyquarter
CREATE TABLE IF NOT EXISTS `rptsalesbyquarter` (
  `quarter` varchar(30) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbystorelocation
CREATE TABLE IF NOT EXISTS `rptsalesbystorelocation` (
  `store_location` varchar(100) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbyweathercondition
CREATE TABLE IF NOT EXISTS `rptsalesbyweathercondition` (
  `weather_condition` varchar(100) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rptsalesbyyear
CREATE TABLE IF NOT EXISTS `rptsalesbyyear` (
  `year` int(11) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rpttopcustomersbysale
CREATE TABLE IF NOT EXISTS `rpttopcustomersbysale` (
  `customer_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.rpttopsellingproducts
CREATE TABLE IF NOT EXISTS `rpttopsellingproducts` (
  `product_id` int(11) DEFAULT NULL,
  `sales_amount` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.salesorder
CREATE TABLE IF NOT EXISTS `salesorder` (
  `order_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table aiqchallenge.weatherinfo
CREATE TABLE IF NOT EXISTS `weatherinfo` (
  `temperature` float DEFAULT NULL,
  `conditions` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `synced_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
